import os
from unittest import result
from dotenv import load_dotenv
import zipfile
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from .bot_core import CodeBot, find_relevant_files, extract_code, read_file, difflib, write_file, get_file_type, verify_typescript, verify_json, verify_code
from rest_framework.decorators import api_view
from rest_framework.response import Response
import json

load_dotenv()

UPLOAD_DIR = os.path.join(settings.MEDIA_ROOT, "projects")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@csrf_exempt
def upload_project(request):
    """Upload a ZIP project file and return extracted path"""
    if request.method == "POST" and request.FILES.get("file"):
        project_file = request.FILES["file"]
        print("***project_file", project_file)
        # Save uploaded file
        zip_path = os.path.join(UPLOAD_DIR, project_file.name)
        with open(zip_path, "wb+") as dest:
            for chunk in project_file.chunks():
                dest.write(chunk)

        # Extract if zip
        if project_file.name.endswith(".zip"):
            extract_dir = zip_path.replace(".zip", "")
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(extract_dir)
            project_path = extract_dir
        else:
            project_path = zip_path

        return JsonResponse({"status": "uploaded", "project_path": project_path})

    return JsonResponse({"error": "No file uploaded"}, status=400)


def fix_bug_view(request):
    """Fix bug in uploaded project"""
    bug_description = request.GET.get("desc")
    project_path = request.GET.get("project")
    print("project_path", project_path)

    if not bug_description or not project_path:
        return JsonResponse({
            "status": "error",
            "message": "Please provide both ?desc and ?project params"
        }, status=400)

    groq_api_key = os.getenv("GROQ_API_KEY")
    if not groq_api_key:
        print("Error: GROQ_API_KEY not found in .env")
        return JsonResponse({
            "status": "error",
            "message": "GROQ_API_KEY not configured"
        }, status=500)

    # Call the CodeBot to fix the bug
    bot = CodeBot(project_path=project_path, groq_api_key=groq_api_key)
    bot.smart_fix_bug(bug_description)

    return JsonResponse({
        "status": "success",
        "filePathwithName": "",  # or actual file path if available
        "message": f"Bug fixing started for: {bug_description}"
    }, status=200)


@csrf_exempt
def preview_fix(request):
    if request.method != "POST":
        return JsonResponse({"error": "Only POST allowed"}, status=405)

    try:
        body = json.loads(request.body.decode("utf-8"))
        bug_description = body.get("bug_description")
        project_path = body.get("project_path")


        bot = CodeBot(groq_api_key=os.getenv("GROQ_API_KEY"), gemini_api_key= os.getenv("GEMINI_API_KEY"))
        bot.project_path = project_path  # Set project path from request

        relevant_files = find_relevant_files(bot.project_path, bug_description)
        if not relevant_files:
            return JsonResponse({"message": "No relevant files found for this bug."})

        previews = []
        for file_path, score in relevant_files[:3]:  # unpack tuple correctly
            preview = bot._propose_fix(file_path, bug_description)
            previews.append(preview)

        return JsonResponse({"previews": previews}, safe=False)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
def apply_fix(request):
    if request.method != "POST":
        return JsonResponse({"error": "Only POST allowed"}, status=405)

    try:
        body = json.loads(request.body.decode("utf-8"))
        file_path = body.get("file_path")
        fixed_code = body.get("fixed_code")
        prompt = body.get("prompt", "")

        if not file_path or not fixed_code:
            return JsonResponse({"error": "file_path and fixed_code are required"}, status=400)
        
        if prompt.strip().lower() != "yes":
            return JsonResponse({
                "status": "skipped",
                "message": "Fix not applied because prompt was not 'Yes'"
            })


        bot = CodeBot(groq_api_key=os.getenv("GROQ_API_KEY"))
        result = bot._apply_fix(file_path, fixed_code, prompt)

        return JsonResponse(result, safe=False)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({"error": str(e)}, status=500)